MAV_STATUS_ENDPOINT = 'https://dev.ocius.com.au/usvna/oc_server?mavstatus&nodeflate'
LIST_ROBOTS_ENDPOINT = 'https://dev.ocius.com.au/usvna/oc_server?listrobots&nodeflate'
SUPPORTED_DRONES = ['Bob', 'Bruce']